# Local execution limits

These project-owner limits apply to implementation, debugging, review, and validation. They constrain skill workflows and instructions such as "complete the matrix," "loop until verified," or "resolve sibling gaps." Long useful implementation work is acceptable. Repeated testing, coordination overhead, and unrequested scope expansion must not dominate the task. A request to resume does not itself authorize additional expensive validation or scope expansion.

## Bounded tasks

- There is no default total implementation time cap. Continue useful work on the requested objective while making concrete progress. Honor any explicit user budget or deadline.
- Track elapsed work by purpose: requested implementation/investigation, necessary validation, repeated validation, and coordination/documentation overhead. At phase changes and roughly every 15 minutes during sustained work, assess whether recent effort is advancing the requested deliverable. This is a decision checkpoint, not an instruction to generate more status documents.
- If repeated testing, avoidable coordination, bookkeeping, or unrequested work accounts for most of the recent runtime, pause that overhead immediately. Identify the cause and choose a cheaper targeted check, reuse valid evidence, or defer the expensive work with an explicit validation limitation. Do not wait for hours or continue the same loop. Continue independent useful implementation where possible.
- Name the specific defects, intended files/modules, and permitted checks before editing. A newly discovered issue outside that boundary becomes a follow-up, not an automatic extension. Do not turn a narrow repair into aggregate C22/C23, FCE, or episode closure unless explicitly requested.
- Do not introduce a performance optimization, identity algorithm change, schema redesign, or broad fixture migration to make a repair's validation finish. Record the need as a separate task unless the user specifically requests it.
- Report incomplete evidence honestly. Hand back a concrete checkpoint when progress requires a scope decision or separately authorized expensive validation. These limits do not permit weakening validators, tests, privacy, or acceptance criteria.

## Validation execution

- Add or run tests only when the user requests testing or validation. A requested focused check does not authorize the full suite, soak tests, or long episode witnesses.
- Known long tests, the 1,000-turn chain, full episode sweeps, benchmarks, and full-suite runs require explicit authorization naming that workload. General implementation/review/validation authorization is insufficient.
- Give validation commands real process timeouts based on expected duration; use 180 seconds by default for short checks. An explicitly authorized longer workload may use an appropriate stated timeout. A tool's yield/poll timeout is not a process timeout. Do not start unbounded validation if termination of the launched workload and its children cannot be enforced.
- Run one test workload at a time, including across subagents. Use visible progress output and exact positive test selectors; confirm selector behavior before execution. Avoid broad test-file or exclusion-pattern commands when they may include a known expensive witness.
- Freeze relevant source files before validation. Reuse passing evidence for unchanged inputs; after an edit, rerun only affected checks. Do not restart a whole passing matrix because one case failed or a documentation-only hash changed.
- Allow one targeted diagnostic rerun of an unchanged failed or timed-out check. If it still fails, inspect the cause or checkpoint the payload, command, failure, and source hashes. Further checks must test a concrete new hypothesis or relevant correction; do not cycle through broad reruns or increase timeouts automatically.
- A changed diagnostic assertion must retain the intended semantic rejection proof. Do not weaken it to accept unrelated earlier failures merely to make the suite pass.
- Before handoff, stop only processes launched by this task and state any pending checks. Do not terminate user-owned processes.

## Delegation and reporting

- Delegation shares the parent's scope and validation limits. Communicate any explicit user deadline and require authorized subagents to avoid tests while another workload runs. Do not duplicate a subagent's checks without a specific verification need. Use lowercase Pokemon names for subagent task names in this repository.
- Progress updates must identify a concrete result, scope change, or remaining blocker. Repeated "final checks" updates do not justify continued overhead.
- Keep checkpoint documentation concise and update existing records. Do not repeatedly reseal documentation and rerun validation while implementation is still changing.

# Project Context

<!-- BEGIN WM AI SHARED BLOCK -->
## WM Shared AI Assets (Codex)

This project uses West Monroe shared AI assets exported from the central repo.

Codex-native portable skills live in `.agents/skills/`.
Project-scoped custom agents live in `.codex/agents/` and can be spawned by name.
Portable skills still live in `.agents/skills/` as the shared source of truth. Load the relevant `SKILL.md` on demand instead of rewriting the workflow from scratch.

Requirements workflow: spec-first

Use `docs/requirements/spec.md` as the source of truth for product behavior, constraints, validation rules, and implementation slices.
Create user stories only when explicitly requested.

Selected packs: `foundation`, `delivery`

WM shared assets:
- `wm-spec` — Generate an automation-friendly product specification from a raw requirement or feature brief.
- `wm-backlog` — Turn a specification, requirements, or stories into a prioritized MVP backlog with sequencing and delivery guidance.
- `wm-qa-plan` — Create a concise QA plan, scenario matrix, seed-data approach, and smoke-test checklist.
- `wm-application-smoke-test` — Run a focused, evidence-based smoke test against a web app, API, CLI, worker, or full-stack application using a verified native runner when available or safe live execution as a fallback; do not generate test scaffolding.
- `wm-pr-review` — Review a change against West Monroe quality, security, testing, and client-delivery expectations.
- `wm-adr` — Generate a West Monroe-style architecture decision record from the current decision context.
- `wm-client-handoff` — Review a client-facing deliverable for readiness, professionalism, and West Monroe engagement standards.
- `product-specification-agent` — Convert a product brief into an automation-friendly product specification with requirements, flows, contracts, validation rules, and implementation slices.
- `backlog-prioritization-agent` — Convert requirements into an MVP backlog with dependency-aware sequencing and delivery recommendations.
- `full-stack-delivery-agent` — Implement a scoped feature with tests, product docs, architecture/workflow docs, and dependency manifests while following existing codebase patterns.
- `qa-validation-agent` — Validate requirements coverage, setup docs, architecture/workflow docs, dependency manifests, seed data, and smoke checks for a demo-ready increment.
- `codebase-onboarding-agent` — Explore a codebase and produce an onboarding guide that gets a new engineer productive quickly.
- `product-delivery-orchestrator` — Act as a PM-style orchestrator that coordinates the active requirements workflow, backlog, implementation, QA, README, architecture/workflow docs, and dependency readiness.

Working guidance:
- Think before coding: state assumptions, surface ambiguity, present tradeoffs, and ask when unclear.
- Keep solutions simple: write the minimum code required and avoid speculative features, abstractions, or configurability.
- Make surgical changes: touch only what the task requires, match existing style, and clean up only artifacts created by the current change.
- Execute against verifiable goals: define success criteria, add or use checks where practical, and loop until verified.
- Start with the smallest relevant skill or agent-skill instead of a broad freeform prompt.
- Use `product-delivery-orchestrator` when you want a visible product-to-backlog-to-delivery flow.
- For generated or changed applications, keep `README.md` current with product usage, dependency installation, environment setup, run commands, and test commands.
- Keep system documentation current when implementation changes architecture or workflows: update or create `docs/architecture.md` for structure, boundaries, data flow, integrations, and key decisions; update or create `docs/workflows.md` for user, operational, or agentic workflows.
- Keep dependency manifests current. Create the stack-native manifest when missing, such as `requirements.txt` or `pyproject.toml` for Python and `package.json` for Node.
- Prefer updating existing docs and artifacts rather than creating duplicate files.
- Preserve project-local skills and agents. Treat WM shared assets as a baseline to extend, not as a replacement for team-owned workflows.
- Keep outputs grounded in repo context, requirements, tests, and delivery constraints.
<!-- END WM AI SHARED BLOCK -->
